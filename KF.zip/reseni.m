clc
clear
close all

%%
%parametry simulace
Ts = 0.1;
TMAX = 20;
t = 0:Ts:TMAX;
steps = length(t);

%system
A=kron([1 Ts; 0 1], eye(2));
B=kron([Ts^2/2; Ts], eye(2));
C=[eye(2) zeros(2)];

%parametry sumu
%procesni sum
q = 5;
Q = q*kron([Ts^3/3 Ts^2/2;Ts^2/2 Ts], eye(2)); 

%sum mereni
%studentuv
r = 5;
R_st = r * eye(2);
nu = 5;
%normalni
R_n = R_st * nu /(nu-2);


%% simulace - urceni MSE algoritmu
%inicializacni hodnoty
x_0 = [0; 0; 0; 0];
P_0 = 100*eye(4);
Sigma_0 = 0.1*eye(2);
s_0 = 0.1;

algoritmy  = ["KF"; "STF"; "KF R"; "STF R"; "RTSS"; "STS"; "KS R"; "STS R"];
odchylky_n = zeros([length(algoritmy) 2]);
odchylky_st = zeros([length(algoritmy) 2]);
avg_R_n = cell([1, 4]);
for k = 1:numel(avg_R_n)
    avg_R_n{k} = zeros(size(R_n));
end
avg_R_st = avg_R_n;


iters = 1000;
bar = waitbar(0, "Probíhá simulace, část 1: 0 %");

for j = 1:iters
%generovani vstupu
u = zeros([2 steps]);
u(:, 1:floor(steps*1/4)) = 1;
u(:, floor(steps*3/4):steps) = -1;
u = num2cell(u, 1);

%generovani procesniho sumu
w = mvnrnd(zeros(1, length(Q)), Q, steps)';

%generovani stavu
x_real = zeros([height(A) steps]);
x_real(:, 1) = x_0;
for i = 2:1:steps
    x_real(:, i) = A * x_real(:, i-1) + B*u{i-1} + w(:, i-1);
end

%generovani sumu mereni
e_n = mvnrnd(zeros(1, length(R_n)), R_n, steps)'; %normalni
e_st = mvtrnd(R_st, nu, steps)'; %studentuv

%generovani vystupu
y = zeros([height(C) steps]);
for i = 1:1:steps
   y(:, i) = C*x_real(:, i); 
end

%vystupy zatizene sumem
y_n = y + e_n;
y_st = y + e_st;

% estimace stavu pro system zatizeny normalnim sumem
[x_f_KF_n, ~] = KF(u, y_n, x_0, P_0, A, B, C, Q, R_n);
[x_s_RTSS_n, ~] = RTSS(u, y_n, x_0, P_0, A, B, C, Q, R_n);
[x_f_STF_n, ~] = STF(u, y_n, x_0, P_0, A, B, C, Q, nu, R_st);
[x_s_STS_n, ~] = STS(u, y_n, x_0, P_0, A, B, C, Q, nu, R_st);
[x_f_KF_R_n, ~, R_KF_R_n] = KF_R(u, y_n, x_0, P_0, A, B, C, Q, Sigma_0, s_0);
[x_s_KS_R_n, ~, R_KS_R_n] = KS_R(u, y_n, x_0, P_0, A, B, C, Q, Sigma_0, s_0);
[x_f_STF_R_n, ~, R_STF_R_n] = STF_R(u, y_n, x_0, P_0, A, B, C, Q, nu, Sigma_0, s_0);
[x_s_STS_R_n, ~, R_STS_R_n] = STS_R(u, y_n, x_0, P_0, A, B, C, Q, nu, Sigma_0, s_0);

vysledky_n = {x_f_KF_n, x_f_STF_n, x_f_KF_R_n, x_f_STF_R_n, x_s_RTSS_n, x_s_STS_n, x_s_KS_R_n, x_s_STS_R_n};
R = {R_KF_R_n, R_KS_R_n, R_STF_R_n, R_STS_R_n};

for i = 1:numel(vysledky_n)
     [MSE_r, MSE_v] = MSE(cell2mat(vysledky_n{i}), x_real);
     odchylky_n(i, 1)= ((j-1)*odchylky_n(i,1)+MSE_r)/j; 
     odchylky_n(i, 2)= ((j-1)*odchylky_n(i,2)+MSE_v)/j;
end

for i = 1:numel(R)
     avg_R_n{i} = ((j-1)*avg_R_n{i}+R{i})/j;
end

% estimace stavu pro system zatizeny studentovym sumem
[x_f_KF_st, ~] = KF(u, y_st, x_0, P_0, A, B, C, Q, R_n);
[x_s_RTSS_st, ~] = RTSS(u, y_st, x_0, P_0, A, B, C, Q, R_n);
[x_f_STF_st, ~] = STF(u, y_st, x_0, P_0, A, B, C, Q, nu, R_st);
[x_s_STS_st, ~] = STS(u, y_st, x_0, P_0, A, B, C, Q, nu, R_st);
[x_f_KF_R_st, ~, R_KF_R_st] = KF_R(u, y_st, x_0, P_0, A, B, C, Q, Sigma_0, s_0);
[x_s_KS_R_st, ~, R_KS_R_st] = KS_R(u, y_st, x_0, P_0, A, B, C, Q, Sigma_0, s_0);
[x_f_STF_R_st, ~, R_STF_R_st] = STF_R(u, y_st, x_0, P_0, A, B, C, Q, nu, Sigma_0, s_0);
[x_s_STS_R_st, ~, R_STS_R_st] = STS_R(u, y_st, x_0, P_0, A, B, C, Q, nu, Sigma_0, s_0);

vysledky_st = {x_f_KF_st, x_f_STF_st, x_f_KF_R_st, x_f_STF_R_st, x_s_RTSS_st, x_s_STS_st, x_s_KS_R_st, x_s_STS_R_st};
R = {R_KF_R_st, R_KS_R_st, R_STF_R_st, R_STS_R_st};

for i = 1:numel(vysledky_st)
     [MSE_r, MSE_v] = MSE(cell2mat(vysledky_st{i}), x_real);
     odchylky_st(i, 1)= ((j-1)*odchylky_st(i,1)+MSE_r)/j; 
     odchylky_st(i, 2)= ((j-1)*odchylky_st(i,2)+MSE_v)/j;
     
end

for i = 1:numel(R)
    avg_R_st{i} = ((j-1)*avg_R_st{i}+R{i})/j;
end

waitbar(j/iters, bar, "Probíhá simulace, část 1: " + num2str(100*j/iters)+ " %");

end
close(bar)

tabulka = table('RowNames',algoritmy);
tabulka.("MSE Normalní šum [poloha | rychlost]") = odchylky_n;
tabulka.("MSE Studentův šum [poloha | rychlost]") = odchylky_st;
save("tabulka.mat", "tabulka")

%% simulace - testování proti výpadkům měření

for j = 1:10
%generovani vstupu
u = zeros([2 steps]);
u(:, 1:floor(steps*1/4)) = 1;
u(:, floor(steps*3/4):steps) = -1;
u = num2cell(u, 1);

%generovani procesniho sumu
w = mvnrnd(zeros(1, length(Q)), Q, steps)';

%generovani stavu
x_real = zeros([height(A) steps]);
x_real(:, 1) = x_0;
for i = 2:1:steps
    x_real(:, i) = A * x_real(:, i-1) + B*u{i-1} + w(:, i-1);
end
x{j} = x_real;

%generovani sumu mereni
e = mvnrnd(zeros(1, length(R_n)), R_n, steps)'; 
t_var = 50:50:steps; %časy ve kterých naroste variance
e_100 = mvnrnd(zeros(1, length(R_n)), 100*R_n, numel(t_var))';
e(:, t_var) = e_100;

%generovani vystupu
y = zeros([height(C) steps]);
for i = 1:1:steps
   y(:, i) = C*x_real(:, i); 
end

y_test{j} = y + e;
end
%% nalezeni optimalnich parametru pro KF
r_n = logspace(0, 2, 100);

bar = waitbar(0, "Probíhá hledání optimálních parametrů pro KF: 0 %");
iters = numel(r_n);
MSE_KF = zeros(iters, 1);

for i = 1:iters
R_test = r_n(i)*eye(2);

for j = 1:10
[x_f_KF, ~] = KF(u, y_test{j}, x_0, P_0, A, B, C, Q, R_test);
x_pred = circshift(A*cell2mat(x_f_KF)+B*cell2mat(u), 1, 2);
x_pred(:, 1) = x_0;
chyba_pred = C*x_pred-y_test{j};

MSE_KF(i) = ((j-1)*MSE_KF(i)+mean(chyba_pred(1,:).^2)+mean(chyba_pred(2,:).^2))/j;
end
waitbar(i/iters, bar,"Probíhá hledání optimálních parametrů pro KF: " + num2str(100*i/iters)+ " %");
end
close(bar)

%%
figure
semilogx(r_n, MSE_KF)
xlabel("r [m^2]")
ylabel("MSE [m^2]")
grid on
title("Závislost chyby predikce na zvolených parametrech algoritmu")

%% nalezeni optimalnich parametru pro STF
r_st = logspace(0, 2, 50);
nu = 3:1:25;
[nu_grid, r_grid] = meshgrid(nu, r_st);

bar = waitbar(0, "Probíhá hledání optimálních parametrů pro STF: 0 %");
iters = numel(nu_grid);
MSE_STF = zeros(size(nu_grid));

for i = 1:iters
R_test = r_grid(i)*eye(2);

for j = 1:10
[x_f_STF, ~] = STF(u, y_test{j}, x_0, P_0, A, B, C, Q, nu_grid(i), R_test);

x_pred = circshift(A*cell2mat(x_f_STF)+B*cell2mat(u), 1, 2);
x_pred(:, 1) = x_0;
chyba_pred = C*x_pred-y_test{j};

MSE_STF(i)=((j-1)*MSE_STF(i)+mean(chyba_pred(1,:).^2+(chyba_pred(2,:).^2)))/j;
end
waitbar(i/iters, bar,"Probíhá hledání optimálních parametrů pro STF: " + num2str(100*i/iters)+ " %");
end
close(bar)

%%
figure
surf(nu_grid, r_grid, MSE_STF, 'EdgeColor', 'none')
set(gca, 'YScale', 'log')
xlabel('\nu')
ylabel('r [m^2]')
zlabel('MSE [m^2]')
colormap parula
colorbar
title("Závislost chyby predikce na zvolených parametrech algoritmu")

%% nalezeni optimalnich parametru pro STF_R
nu = 3:0.5:50;

bar = waitbar(0, "Probíhá hledání optimálních parametrů pro STF_R: 0 %");
iters = numel(nu);
MSE_STF_R = zeros(1,iters);

for v = 1:iters
for j = 1:10
[x_f_STF_R, ~, ~] = STF_R(u, y_test{j}, x_0, P_0, A, B, C, Q, nu(v), Sigma_0, s_0);

x_pred = circshift(A*cell2mat(x_f_STF_R)+B*cell2mat(u), 1, 2);
x_pred(:, 1) = x_0;
chyba_pred = C*x_pred-y_test{j};

MSE_STF_R(v)=((j-1)*MSE_STF_R(v)+mean(chyba_pred(1,:).^2)+mean(chyba_pred(2,:).^2))/j;
end
waitbar(v/iters, bar,"Probíhá hledání optimálních parametrů pro STF_R: " + num2str(100*v/iters)+ " %");
end
close(bar)

%%
figure
plot(nu, MSE_STF_R)
xlabel("\nu")
ylabel("MSE [m^2]")
grid on
title("Závislost chyby predikce na zvolených parametrech algoritmu")

%% testování filtračních algoritmů s optimálními parametry

%optimalni parametry
[~, idx_KF] = min(MSE_KF);
opt_R_KF = r_n(idx_KF)*eye(2);

[~, idx_STF] = min(MSE_STF(:));
opt_R_STF = r_grid(idx_STF)*eye(2);
opt_nu_STF = nu_grid(idx_STF);

[~, idx_STF_R] = min(MSE_STF_R);
opt_nu_STF_R = nu(idx_STF_R);
SE_r = cell(1,4);
for i = 1:numel(SE_r)
    SE_r{i} = zeros(1, steps);
end
SE_v = SE_r;

for j = 1:10    
[x_f_KF, ~] = KF(u, y_test{j}, x_0, P_0, A, B, C, Q, opt_R_KF);
[x_f_STF, ~] = STF(u, y_test{j}, x_0, P_0, A, B, C, Q, opt_nu_STF, opt_R_STF);
[x_f_KF_R, ~, ~] = KF_R(u, y_test{j}, x_0, P_0, A, B, C, Q, Sigma_0, s_0);
[x_f_STF_R, ~, ~] = STF_R(u, y_test{j}, x_0, P_0, A, B, C, Q, opt_nu_STF_R, Sigma_0, s_0);

vysledky = {x_f_KF, x_f_STF, x_f_KF_R, x_f_STF_R};
for i = 1:numel(SE_r) 
    chyba = cell2mat(vysledky{i})-x{j};
    SE_r{i} = ((j-1)*SE_r{i}+sum(chyba(1:2,:).^2))/j;
    SE_v{i} = ((j-1)*SE_v{i}+sum(chyba(3:4,:).^2))/j;

end

end

%%
figure
tiledlayout(2, 1, TileSpacing="tight")
nexttile
for i = 1:numel(SE_r)
    plot(t, SE_r{i})
    hold on
end
legend("KF", "STF", "KF R", "STF R")
grid on
xlabel("t [s]")
ylabel("SE_p [m^2]")
for k = 1:numel(t_var)
    l = xline(t(t_var(k)), 'r', 'LineWidth', 1);
    l.Annotation.LegendInformation.IconDisplayStyle = 'off';
    drawnow
end
title("Průběh odchylky polohy v čase pro různé algoritmy")
hold off
nexttile
for i = 1:numel(SE_v)
    plot(t, SE_v{i})
    hold on
end
legend("KF", "STF", "KF R", "STF R")
grid on
xlabel("t [s]")
ylabel("SE_v [(m/s)]^2")
for k = 1:numel(t_var)
    l = xline(t(t_var(k)), 'r', 'LineWidth', 1);
    l.Annotation.LegendInformation.IconDisplayStyle = 'off';

    drawnow
end
hold off
title("Průběh odchylky rychlosti v čase pro různé algoritmy")