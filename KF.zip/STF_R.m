function [x_f,P_f, R] = STF_R(u, y, x_0, P_0, A, B, C, Q, nu, Sigma_0, s_0)
mathring_y = height(y);
steps = width(y);
x_pred = cell([1 steps]);
x_f = cell([1 steps]);
P_pred = cell([1 steps]);
P_f = cell([1 steps]);
Sigma = cell([1 steps]);
s = cell([1 steps]);
y = num2cell(y, 1);

x_pred{1} = x_0;
P_pred{1} = P_0;
Sigma{1} = Sigma_0;
s{1} = s_0+1;

iters = 100; %pocet iteraci IVB algoritmu

m = nu + mathring_y;
I = eye(length(x_0));

for k = 1:steps
   %datovy krok
   P = cell(1, iters);
   x = cell(1, iters);
   Sigma_i = cell(1, iters);
   Sigma_i{1} = Sigma{k};
   l = cell(1, iters);

   P{1} = P_pred{k};
   x{1} = x_pred{k};
   
   s{k+1} = s{k}+1;
   for i = 2:iters
       l{i} = nu+trace(s{k}*Sigma_i{i-1}^-1*((y{k}-C*x{i-1})*(y{k}-C*x{i-1})'+C*P{i-1}*C'));
       Sigma_i{i} = Sigma{k}+m/l{i}*((y{k}-C*x{i-1})*(y{k}-C*x{i-1})'+C*P{i-1}*C');
       
       R = Sigma_i{i}/s{k};  % \hat{R^-1}^-1
       exp_cov = (R^-1*m/l{i})^-1;
       K = P_pred{k}*C'/(exp_cov+C*P_pred{k}*C');
       P{i} = (I-K*C)*P_pred{k}*(I-K*C)'+K*exp_cov*K';
       x{i} = x_pred{k} + K*(y{k}-C*x_pred{k});

   end
   x_f{k} = x{end};
   P_f{k} = P{end};
   Sigma{k} = Sigma_i{end};

   %casovy krok
   P_pred{k+1} = Q + A*P_f{k}*A';
   x_pred{k+1} = A*x_f{k} + B*u{k};
   Sigma{k+1} = Sigma{k};
end
end